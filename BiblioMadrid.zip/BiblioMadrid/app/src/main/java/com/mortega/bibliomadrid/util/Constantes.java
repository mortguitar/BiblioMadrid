package com.mortega.bibliomadrid.util;

public class Constantes {

    public static final String URL = "https://datos.madrid.es/portal/site/egob/menuitem.ac61933d6ee3c31cae77ae7784f1a5a0/?vgnextoid=00149033f2201410VgnVCM100000171f5a0aRCRD&format=json&file=0&filename=212763-0-biblioteca-universitaria&mgmtid=a9e237ac37efb410VgnVCM2000000c205a0aRCRD&preview=full";
}
